export async function onRequestPost({ request, env }) {
  try {
    if (!env.GEMINI_API_KEY) {
      return Response.json({ reply: "ALEX ka AI brain abhi connect nahi hai. Cloudflare Settings > Variables and Secrets mein GEMINI_API_KEY add karo." }, { status: 200 });
    }
    const body = await request.json();
    const message = String(body.message || "").slice(0, 8000);
    const moduleName = String(body.module || "general").slice(0, 40);
    const model = env.GEMINI_MODEL || "gemini-2.5-flash-lite";
    const prompt = `You are ALEX, a friendly all-in-one personal AI assistant. Current workspace: ${moduleName}.
Help with general questions, job search planning, safe earning ideas, YouTube creation and personal planning.
Use simple language and adapt to the user's language. Never claim an external action was completed unless a connected tool confirms it.
Ask explicit approval before sending messages, submitting applications, spending money, deleting data or changing accounts.
Warn about job scams, upfront fees, OTP requests and password requests.
User message: ${message}`;
    const upstream = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${env.GEMINI_API_KEY}`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ contents: [{ parts: [{ text: prompt }] }] })
      }
    );
    const data = await upstream.json();
    if (!upstream.ok) {
      return Response.json({ reply: "Gemini API ne request reject ki. API key, model availability aur free quota check karo." }, { status: 200 });
    }
    const reply = data?.candidates?.[0]?.content?.parts?.map(p => p.text || "").join("\n") || "ALEX ko is baar jawab nahi mila. Dobara try karo.";
    return Response.json({ reply });
  } catch (err) {
    return Response.json({ reply: "ALEX server mein temporary problem aayi. Thodi der baad dobara try karo." }, { status: 200 });
  }
}
