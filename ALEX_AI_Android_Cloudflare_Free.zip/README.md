# ALEX AI — Android-first, free-tier deploy starter

This edition uses Cloudflare Pages + Pages Functions so the Gemini API key stays server-side.
You can deploy it from an Android phone using the GitHub and Cloudflare mobile websites.

## Before starting

- Create/sign in to GitHub: https://github.com/
- Create/sign in to Cloudflare: https://dash.cloudflare.com/
- Create a Gemini API key: https://aistudio.google.com/
- Check current Gemini free-tier limits and data terms: https://ai.google.dev/gemini-api/docs/pricing

## Deploy from Android

1. Download and extract this ZIP on your phone (Files app → Downloads → ZIP → Extract).
2. In Chrome, open GitHub and create a **new public repository** named `alex-ai`.
3. Open the repository → **Add file → Upload files**. Upload all extracted files and folders. The repository root must contain `index.html`, `functions/`, `style.css`, `app.js`, and `manifest.webmanifest`. Commit the upload.
4. Open Cloudflare Dashboard → **Workers & Pages** → **Create application** → **Pages** → **Connect to Git**.
5. Connect GitHub and select the `alex-ai` repository.
6. For framework preset choose **None**. Set Build command to blank (or no build command) and Build output directory to `/`. Save and deploy.
7. After deployment, open the Pages project → **Settings → Variables and Secrets** (or Functions environment variables, depending on dashboard layout).
8. Add a secret named `GEMINI_API_KEY` and paste the key from Google AI Studio. Add a plain variable `GEMINI_MODEL` with value `gemini-2.5-flash-lite` if desired.
9. Redeploy if the dashboard asks you to. Open the `*.pages.dev` URL.
10. On Android Chrome, allow microphone permission. Use the mic button for speech input and the speaker button on replies. Chrome menu → **Add to Home screen** to install the app shortcut.

## Important

- Do not put the Gemini key in HTML or JavaScript. Only store it as a Cloudflare secret.
- Free plans have quotas/limits and service terms can change. Check current Cloudflare Pages/Workers limits.
- Gemini free tier has limited model access and quotas; free-tier content may be used to improve Google products. Do not send sensitive personal, medical, financial or confidential information.
- Browser speech recognition varies by browser/device/language. Text-to-speech uses the browser's built-in voice.
- Job searching, sending emails, submitting applications, reminders and YouTube publishing are not connected external actions yet; this starter can help draft and plan them.
- For public production use, add authentication, per-user isolation, abuse controls and monitoring.
